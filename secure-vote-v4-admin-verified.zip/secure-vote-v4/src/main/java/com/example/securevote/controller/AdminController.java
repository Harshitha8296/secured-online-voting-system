package com.example.securevote.controller;

import com.example.securevote.entity.Nominee;
import com.example.securevote.repository.NomineeRepository;
import com.example.securevote.repository.VoteRepository;
import com.example.securevote.repository.VoterRepository;
import com.example.securevote.service.FileStorageService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final VoterRepository vr;
    private final NomineeRepository nr;
    private final VoteRepository voteRepository;
    private final FileStorageService fs;

    public AdminController(VoterRepository v, NomineeRepository n, VoteRepository votes, FileStorageService f) {
        vr = v; nr = n; voteRepository = votes; fs = f;
    }

    private boolean ok(HttpSession s) { return Boolean.TRUE.equals(s.getAttribute("admin")); }

    @GetMapping("/dashboard")
    String d(HttpSession s, Model m) {
        if (!ok(s)) return "redirect:/admin-login";
        m.addAttribute("voters", vr.findAll());
        m.addAttribute("nominees", nr.findAll());
        m.addAttribute("pendingVotes", voteRepository.findByStatusOrderByVotedAtDesc("PENDING"));
        return "admin-dashboard";
    }

    @PostMapping("/verify/{id}")
    String verifyVoter(@PathVariable Long id, HttpSession s) {
        if (ok(s)) vr.findById(id).ifPresent(x -> {
            x.setVerified(true);
            x.setRejected(false);
            vr.save(x);
        });
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/reject/{id}")
    String rejectVoter(@PathVariable Long id, HttpSession s) {
        if (ok(s)) vr.findById(id).ifPresent(x -> {
            x.setVerified(false);
            x.setRejected(true);
            vr.save(x);
        });
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/vote/approve/{id}")
    String approveVote(@PathVariable Long id, HttpSession s) {
        if (!ok(s)) return "redirect:/admin-login";
        voteRepository.findById(id).ifPresent(vote -> {
            if ("PENDING".equals(vote.getStatus()) && !vote.getVoter().isHasVoted()) {
                vote.setStatus("APPROVED");
                voteRepository.save(vote);
                var nominee = vote.getNominee();
                nominee.setVoteCount(nominee.getVoteCount() + 1);
                nr.save(nominee);
                var voter = vote.getVoter();
                voter.setHasVoted(true);
                vr.save(voter);
            }
        });
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/vote/reject/{id}")
    String rejectVote(@PathVariable Long id, HttpSession s) {
        if (!ok(s)) return "redirect:/admin-login";
        voteRepository.findById(id).ifPresent(vote -> {
            if ("PENDING".equals(vote.getStatus())) {
                vote.setStatus("REJECTED");
                voteRepository.save(vote);
            }
        });
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/nominee/add")
    String add(@RequestParam String name, @RequestParam String party, @RequestParam String description,
               @RequestParam(required=false) MultipartFile candidatePhoto,
               @RequestParam(required=false) MultipartFile symbol, HttpSession s) throws Exception {
        if (!ok(s)) return "redirect:/admin-login";
        Nominee n = new Nominee();
        n.setName(name); n.setParty(party); n.setDescription(description);
        n.setCandidatePhotoPath(fs.save(candidatePhoto, "candidates"));
        n.setSymbolPath(fs.save(symbol, "symbols"));
        nr.save(n);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/nominee/update/{id}")
    String up(@PathVariable Long id, @RequestParam String name, @RequestParam String party,
              @RequestParam String description, @RequestParam(required=false) MultipartFile candidatePhoto,
              @RequestParam(required=false) MultipartFile symbol, HttpSession s) throws Exception {
        if (!ok(s)) return "redirect:/admin-login";
        nr.findById(id).ifPresent(n -> {
            n.setName(name); n.setParty(party); n.setDescription(description);
            try {
                String a = fs.save(candidatePhoto, "candidates"), b = fs.save(symbol, "symbols");
                if (a != null) n.setCandidatePhotoPath(a);
                if (b != null) n.setSymbolPath(b);
            } catch (Exception e) { throw new RuntimeException(e); }
            nr.save(n);
        });
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/nominee/delete/{id}")
    String del(@PathVariable Long id, HttpSession s) {
        if (ok(s)) nr.deleteById(id);
        return "redirect:/admin/dashboard";
    }
}
