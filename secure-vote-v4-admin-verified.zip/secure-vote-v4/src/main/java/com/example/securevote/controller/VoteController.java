package com.example.securevote.controller;

import com.example.securevote.entity.Vote;
import com.example.securevote.repository.NomineeRepository;
import com.example.securevote.repository.VoteRepository;
import com.example.securevote.repository.VoterRepository;
import com.example.securevote.service.FileStorageService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@Controller
public class VoteController {
    private final VoterRepository vr;
    private final NomineeRepository nr;
    private final VoteRepository vot;
    private final FileStorageService fs;

    public VoteController(VoterRepository v, NomineeRepository n, VoteRepository x, FileStorageService f) {
        vr = v; nr = n; vot = x; fs = f;
    }

    @PostMapping("/vote/cast")
    String cast(@RequestParam Long nomineeId,
                @RequestParam String faceVerified,
                @RequestParam("livePhoto") MultipartFile livePhoto,
                HttpSession s, Model m) {
        Long id = (Long) s.getAttribute("voterId");
        if (id == null) return "redirect:/login";

        var v = vr.findById(id).orElse(null);
        var n = nr.findById(nomineeId).orElse(null);
        if (v == null || n == null) return "redirect:/voter/dashboard";

        boolean alreadyVoted = v.isHasVoted() || vot.existsByVoterId(id);
        boolean pending = vot.existsByVoterIdAndStatus(id, "PENDING");

        if (!v.isVerified() || alreadyVoted || pending || !"true".equalsIgnoreCase(faceVerified)
                || livePhoto == null || livePhoto.isEmpty()) {
            m.addAttribute("error", pending
                    ? "Your vote is already submitted and is waiting for admin verification."
                    : "Vote verification failed. Please capture a clear face photo and try again.");
            m.addAttribute("voter", v);
            m.addAttribute("nominees", nr.findAll());
            return "voter-dashboard";
        }

        try {
            String livePath = fs.save(livePhoto, "vote-captures");
            Vote x = new Vote();
            x.setVoter(v);
            x.setNominee(n);
            x.setVotedAt(LocalDateTime.now());
            x.setStatus("PENDING");
            x.setLivePhotoPath(livePath);
            vot.save(x);

            // IMPORTANT: the nominee vote count is NOT increased yet.
            // The admin must review the captured voting photo first.
            return "vote-pending";
        } catch (Exception e) {
            m.addAttribute("error", "Could not save the captured photo. Please try again.");
            m.addAttribute("voter", v);
            m.addAttribute("nominees", nr.findAll());
            return "voter-dashboard";
        }
    }
}
