package com.example.securevote.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "votes")
public class Vote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(optional = false)
    private Voter voter;

    @ManyToOne(optional = false)
    private Nominee nominee;

    private LocalDateTime votedAt = LocalDateTime.now();

    @Column(nullable = false)
    private String status = "PENDING";

    private String livePhotoPath;

    public Long getId() { return id; }
    public Voter getVoter() { return voter; }
    public Nominee getNominee() { return nominee; }
    public LocalDateTime getVotedAt() { return votedAt; }
    public String getStatus() { return status; }
    public String getLivePhotoPath() { return livePhotoPath; }

    public void setVoter(Voter x) { voter = x; }
    public void setNominee(Nominee x) { nominee = x; }
    public void setVotedAt(LocalDateTime x) { votedAt = x; }
    public void setStatus(String x) { status = x; }
    public void setLivePhotoPath(String x) { livePhotoPath = x; }
}
