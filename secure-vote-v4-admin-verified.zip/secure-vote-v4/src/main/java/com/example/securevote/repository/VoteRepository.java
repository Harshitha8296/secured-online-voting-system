package com.example.securevote.repository;

import com.example.securevote.entity.Vote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VoteRepository extends JpaRepository<Vote, Long> {
    boolean existsByVoterId(Long id);
    boolean existsByVoterIdAndStatus(Long id, String status);
    List<Vote> findByStatusOrderByVotedAtDesc(String status);
}
