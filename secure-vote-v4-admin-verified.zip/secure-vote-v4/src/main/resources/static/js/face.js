const MODEL_URL='https://justadudewhohacks.github.io/face-api.js/models';
let stream=null,ready=false,loadingPromise=null;

function setText(id,text){const el=document.getElementById(id);if(el)el.textContent=text;}
function stopCamera(){if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;}

async function models(){
  if(ready)return;
  if(loadingPromise)return loadingPromise;
  loadingPromise=(async()=>{
    if(typeof faceapi==='undefined')throw Error('Face verification library is still loading. Please wait 2–3 seconds and try again.');
    setText('photoStatus','Loading face verification models…');
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
    ]);
    ready=true;
  })();
  try{return await loadingPromise}catch(e){loadingPromise=null;throw e;}
}

async function openRegCamera(){
  try{
    await models();
    stopCamera();
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:640},height:{ideal:480}},audio:false});
    const video=document.getElementById('video');
    video.srcObject=stream;
    await video.play();
    setText('photoStatus','✓ Camera ready. Center your face, then capture.');
  }catch(e){setText('photoStatus','❌ Camera error: '+e.message);}
}

async function captureReg(){
  try{
    if(!stream)await openRegCamera();
    const v=document.getElementById('video');
    if(!v.videoWidth)throw Error('Camera is starting. Please wait one second and click capture again.');
    const c=document.getElementById('canvas');
    c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0,c.width,c.height);
    setText('photoStatus','Checking your face…');
    const d=await faceapi.detectSingleFace(c,new faceapi.TinyFaceDetectorOptions({inputSize:320,scoreThreshold:.5})).withFaceLandmarks().withFaceDescriptor();
    if(!d){setText('photoStatus','❌ No clear face detected. Move closer, face the camera and try again.');return;}
    document.getElementById('faceDescriptor').value=JSON.stringify(Array.from(d.descriptor));
    const src=c.toDataURL('image/jpeg',.92);
    document.getElementById('preview').src=src;
    const blob=await(await fetch(src)).blob(),file=new File([blob],'registration-face.jpg',{type:'image/jpeg'});
    const dt=new DataTransfer();dt.items.add(file);document.getElementById('photo').files=dt.files;
    setText('photoStatus','✓ Face captured and descriptor created. You can submit registration.');
  }catch(e){setText('photoStatus','❌ '+e.message);}
}

async function startVerification(id){
  const modal=document.getElementById('modal');
  modal.style.display='grid';
  document.getElementById('nomineeId').value=id;
  document.getElementById('faceVerified').value='false';
  document.getElementById('livePhoto').value='';
  const b=document.getElementById('voteBtn');b.disabled=true;
  setText('matchStatus','Loading camera and face verification…');
  try{
    await models();
    stopCamera();
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:640},height:{ideal:480}},audio:false});
    const video=document.getElementById('liveVideo');video.srcObject=stream;await video.play();
    b.disabled=false;
    setText('matchStatus','✓ Camera ready. Click “Capture & Verify Face”.');
  }catch(e){setText('matchStatus','❌ '+e.message);}
}

function closeModal(){stopCamera();document.getElementById('modal').style.display='none';}

async function captureAndVerify(){
  const v=document.getElementById('liveVideo'),b=document.getElementById('voteBtn');
  b.disabled=true;
  try{
    if(!v.videoWidth)throw Error('Camera is not ready yet. Please wait and try again.');
    setText('matchStatus','📸 Capturing your voting photo…');
    const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0,c.width,c.height);
    const d=await faceapi.detectSingleFace(c,new faceapi.TinyFaceDetectorOptions({inputSize:320,scoreThreshold:.5})).withFaceLandmarks().withFaceDescriptor();
    if(!d)throw Error('No face detected. Keep your full face inside the camera frame.');
    let ref=window.registeredDescriptor;
    if(typeof ref==='string')ref=JSON.parse(ref);
    if(!Array.isArray(ref)||ref.length!==128)throw Error('Registered face descriptor is missing. Please contact the admin.');
    const dist=faceapi.euclideanDistance(new Float32Array(ref),d.descriptor);
    if(dist>.55){
      document.getElementById('faceVerified').value='false';
      setText('matchStatus','✕ FACE DOES NOT MATCH — distance '+dist.toFixed(3)+'. Try again.');
      b.disabled=false;return;
    }
    const src=c.toDataURL('image/jpeg',.92),blob=await(await fetch(src)).blob(),file=new File([blob],'voting-capture.jpg',{type:'image/jpeg'});
    const dt=new DataTransfer();dt.items.add(file);document.getElementById('livePhoto').files=dt.files;
    document.getElementById('faceVerified').value='true';
    setText('matchStatus','✓ FACE MATCHED — photo captured. Submitting vote for ADMIN VERIFICATION…');
    setTimeout(()=>document.getElementById('voteForm').submit(),700);
  }catch(e){setText('matchStatus','❌ '+e.message);b.disabled=false;}
}

document.addEventListener('DOMContentLoaded',()=>{
  const f=document.getElementById('voteForm');
  if(f)f.addEventListener('submit',e=>{if(document.getElementById('faceVerified').value!=='true'||!document.getElementById('livePhoto').files.length)e.preventDefault();});
});
